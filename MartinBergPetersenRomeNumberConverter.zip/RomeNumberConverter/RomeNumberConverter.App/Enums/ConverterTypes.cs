﻿namespace RomeNumberConverter.App.Enums
{
    public class ConverterTypes
    {
        public enum Converters
        {
            RomanDecimal = 0
        }
    }
}
