﻿namespace RomeNumberConverter.App.Interfaces
{
    public interface IConverter
    {
        string GetResult();
    }
}
